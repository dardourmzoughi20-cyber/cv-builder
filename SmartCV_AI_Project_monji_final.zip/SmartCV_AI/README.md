# SmartCV AI — Intelligent CV Manager

ISET Djerba • Initiation à l’Intelligence Artificielle (2026)

Files included:
- index.html
- SmartCV_AI_Logo.png
- SmartCV_AI_Prompts.txt
